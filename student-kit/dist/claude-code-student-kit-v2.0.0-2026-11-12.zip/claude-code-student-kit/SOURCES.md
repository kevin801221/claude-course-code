# 來源、選材與改寫紀錄

<a id="realtek-sources"></a>

## 瑞昱課後問題與實作 · 2026-11-17

| 學生包案例 | 上游固定版本 | 收錄範圍 |
| --- | --- | --- |
| [Visio MCP](realtek/cases/visio-mcp/STUDENT.md) | [claude-course-code · `b1c5315`](https://github.com/kevin801221/claude-course-code/tree/b1c5315339f8526c07b4d10da2f86ba89f7f8371/Projects/visio-mcp-lab) | 專案 MCP 設定、伺服器、原生起始圖、可重跑的 stdio 測試。 |
| [Windows 桌面 Visio 即時畫圖](realtek/cases/visio-windows-live/README.md) | [GongRzhe/Office-Visio-MCP-Server · `9b56607`](https://github.com/GongRzhe/Office-Visio-MCP-Server/tree/9b566078f9051028ceafe4912409bce9910943bb) | 以鎖定的 PyPI 1.0.1 版提供新增圖形、文字和連線的 MCP 工具。課堂附 Claude Code 設定、啟動器及驗收步驟。 |
| [日週報與長期記憶](realtek/cases/claude-mem/Q2.md) | [claude-mem-application_ · `23ede23`](https://github.com/kevin801221/claude-mem-application_/tree/23ede238b63004166a01299b45911f1c4f87036e) | 報表與檢索共用一個案例目錄，離線課堂資料另以合成紀錄提供。 |
| [Markdown 檢索](realtek/cases/md-retrieval/STUDENT.md) | [compare-claudecode-retrieval-methods · `b741780`](https://github.com/kevin801221/compare-claudecode-retrieval-methods/tree/b7417806ca78bdd98cb54edeb2a04b6b7c402a49) | 以同一題和來源段落示範不同整理方式，完整評測條件請見原始 repo。 |
| [團隊畫圖 Skill](realtek/cases/mermaid-design/STUDENT.md) | [mermaid-design · `bd9216e`](https://github.com/kevin801221/mermaid-design/tree/bd9216ed6cc45b03ea86bf498138d6b7ba9d5594) | 課堂使用的 Skill、排版規則、範例圖與渲染工具。 |
| [剪貼簿翻譯](realtek/cases/clip-translate/STUDENT.md) | [clip-translate · `bb05f1b`](https://github.com/kevin801221/clip-translate/tree/bb05f1bdda1c0eb49dfc4a1c3001c83023d3a7bf) | macOS 腳本與啟停步驟，另附可重跑的受控檢查。 |
| [研究到 PRD／SoW](realtek/cases/autosearch-prd/STUDENT.md) | [autosearch-PRD-claudecode · `f0e10ce`](https://github.com/kevin801221/autosearch-PRD-claudecode/tree/f0e10cef442c46cef9eebda4831225374cc4fbd7) | 講師授權收錄離線程式、模板、測試與合成資料。完整 repo 維持私有。 |

[課後五問與延伸實作索引](realtek/README.md)。個別來源的署名及授權見[隨包注意事項](THIRD_PARTY_NOTICES.md)。

## v2完整課堂版

完整1,784份來源的原路徑、固定commit、byte/hash、Notebook淨化/連結調整與排除理由，見 [sources/full-manifest.json](sources/full-manifest.json)。核心來源入口在 [CLASSROOM.md](CLASSROOM.md)。以下原有49項是v1精選的歷史清單，並非v2全部內容。

整理基準：指定講義與五個本機 Git 快照。逐檔完整資料見 [sources/manifest.json](sources/manifest.json)，含來源/目標路徑、固定 commit、SHA-256 與 copy/adapted/reading-reference 分類。

## 五份快照

| 來源 | 固定 commit | 本包取用 |
|---|---|---|
| [claude-code-best-practice](https://github.com/kevin801221/claude-code-best-practice/tree/17b25b2948ecea4aa5e7e60c4e015876fc7063c7) | `17b25b2948ec` | Command→Agent→Skill 天氣工作流 |
| [claude-code-zh-tw](https://github.com/kevin801221/claude-code-zh-tw/tree/9c6e34d69eee8cf634bbf269df5f812b6e13e987) | `9c6e34d69eee` | 七篇繁中精華導讀與講義脈絡 |
| [claude-course-code](https://github.com/kevin801221/claude-course-code/tree/475fe057ed234f836ff3eb06f4c5eecad9e36332) | `475fe057ed23` | 測試/審查代理、PRP、四代理 ML、Teams 契約 |
| [claude-howto-zh-TW](https://github.com/kevin801221/claude-howto-zh-TW/tree/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e) | `d7f669d6bd16` | Python AST 文件產生器、文件代理與審查模板 |
| [matt-flow-mods](https://github.com/kevin801221/matt-flow-mods/tree/70b50bc1b822eb18d770f8f75588b3b01f77cc27) | `70b50bc1b822` | Matt 導航核心 TSX、型別、原測試與開發腳本 |

## 精選檔案

`copy` 原樣保留、`adapted` 依本包操作情境修改、`reading-reference` 原創導讀引用來源而未搬入全文。新寫的根 CLI、Hook、MCP、Lab 說明、Plugin 與離線 RAG 示範不冒稱為上游原碼。

| 本包位置 | 處理方式 | 原始檔 |
|---|---|---|
| [examples/weather-workflow/.claude/commands/weather-orchestrator.md](examples/weather-workflow/.claude/commands/weather-orchestrator.md) | adapted | [claude-code-best-practice/.claude/commands/weather-orchestrator.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/commands/weather-orchestrator.md) |
| [examples/weather-workflow/.claude/agents/weather-agent.md](examples/weather-workflow/.claude/agents/weather-agent.md) | adapted | [claude-code-best-practice/.claude/agents/weather-agent.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/agents/weather-agent.md) |
| [examples/weather-workflow/.claude/skills/weather-fetcher/SKILL.md](examples/weather-workflow/.claude/skills/weather-fetcher/SKILL.md) | copy | [claude-code-best-practice/.claude/skills/weather-fetcher/SKILL.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/skills/weather-fetcher/SKILL.md) |
| [examples/weather-workflow/.claude/skills/weather-svg-creator/SKILL.md](examples/weather-workflow/.claude/skills/weather-svg-creator/SKILL.md) | adapted | [claude-code-best-practice/.claude/skills/weather-svg-creator/SKILL.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/skills/weather-svg-creator/SKILL.md) |
| [examples/weather-workflow/.claude/skills/weather-svg-creator/reference.md](examples/weather-workflow/.claude/skills/weather-svg-creator/reference.md) | copy | [claude-code-best-practice/.claude/skills/weather-svg-creator/reference.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/skills/weather-svg-creator/reference.md) |
| [examples/weather-workflow/.claude/skills/weather-svg-creator/examples.md](examples/weather-workflow/.claude/skills/weather-svg-creator/examples.md) | copy | [claude-code-best-practice/.claude/skills/weather-svg-creator/examples.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/.claude/skills/weather-svg-creator/examples.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/reports/why-harness-is-important.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/reports/why-harness-is-important.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/reports/claude-agent-command-skill.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/reports/claude-agent-command-skill.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/best-practice/claude-memory.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/best-practice/claude-memory.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/reports/claude-skills-for-larger-mono-repos.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/reports/claude-skills-for-larger-mono-repos.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/tips/claude-thariq-tips-17-mar-26.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/tips/claude-thariq-tips-17-mar-26.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-zh-tw/tips/claude-thariq-tips-16-apr-26.md](https://github.com/kevin801221/claude-code-zh-tw/blob/9c6e34d69eee8cf634bbf269df5f812b6e13e987/tips/claude-thariq-tips-16-apr-26.md) |
| [docs/reading-guide.md](docs/reading-guide.md) | reading-reference | [claude-code-best-practice/orchestration-workflow/orchestration-workflow.md](https://github.com/kevin801221/claude-code-best-practice/blob/17b25b2948ecea4aa5e7e60c4e015876fc7063c7/orchestration-workflow/orchestration-workflow.md) |
| [resources/templates/skills/doc-generator/generate-docs.py](resources/templates/skills/doc-generator/generate-docs.py) | copy | [claude-howto-zh-TW/03-skills/doc-generator/generate-docs.py](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/03-skills/doc-generator/generate-docs.py) |
| [resources/templates/skills/doc-generator/SKILL.md](resources/templates/skills/doc-generator/SKILL.md) | adapted | [claude-howto-zh-TW/03-skills/doc-generator/SKILL.md](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/03-skills/doc-generator/SKILL.md) |
| [resources/templates/review/review-checklist.md](resources/templates/review/review-checklist.md) | copy | [claude-howto-zh-TW/03-skills/code-review-specialist/templates/review-checklist.md](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/03-skills/code-review-specialist/templates/review-checklist.md) |
| [resources/templates/review/finding-template.md](resources/templates/review/finding-template.md) | copy | [claude-howto-zh-TW/03-skills/code-review-specialist/templates/finding-template.md](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/03-skills/code-review-specialist/templates/finding-template.md) |
| [resources/templates/agents/kit-reviewer.md](resources/templates/agents/kit-reviewer.md) | adapted | [claude-course-code/04-subagents/code-reviewer.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/04-subagents/code-reviewer.md) |
| [resources/templates/agents/kit-test-engineer.md](resources/templates/agents/kit-test-engineer.md) | adapted | [claude-course-code/04-subagents/test-engineer.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/04-subagents/test-engineer.md) |
| [resources/templates/agents/kit-docs-writer.md](resources/templates/agents/kit-docs-writer.md) | adapted | [claude-howto-zh-TW/04-subagents/documentation-writer.md](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/04-subagents/documentation-writer.md) |
| [resources/templates/commands/unit-test-expand.md](resources/templates/commands/unit-test-expand.md) | adapted | [claude-course-code/01-slash-commands/unit-test-expand.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/01-slash-commands/unit-test-expand.md) |
| [resources/templates/commands/generate-api-docs.md](resources/templates/commands/generate-api-docs.md) | adapted | [claude-howto-zh-TW/01-slash-commands/generate-api-docs.md](https://github.com/kevin801221/claude-howto-zh-TW/blob/d7f669d6bd1679a6c2e4a0c9b47d4159c018911e/01-slash-commands/generate-api-docs.md) |
| [resources/templates/context/PRP.md](resources/templates/context/PRP.md) | adapted | [claude-course-code/context-engineering-intro/PRPs/templates/prp_base.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/context-engineering-intro/PRPs/templates/prp_base.md) |
| [advanced/project-recipes/wafer/source-agents/data-hunter.md](advanced/project-recipes/wafer/source-agents/data-hunter.md) | copy | [claude-course-code/agent_group_projects/computer-vision-wafer-detection/.claude/agents/data-hunter.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-detection/.claude/agents/data-hunter.md) |
| [advanced/project-recipes/wafer/source-agents/bbox-labeler.md](advanced/project-recipes/wafer/source-agents/bbox-labeler.md) | copy | [claude-course-code/agent_group_projects/computer-vision-wafer-detection/.claude/agents/bbox-labeler.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-detection/.claude/agents/bbox-labeler.md) |
| [advanced/project-recipes/wafer/source-agents/training-runner.md](advanced/project-recipes/wafer/source-agents/training-runner.md) | copy | [claude-course-code/agent_group_projects/computer-vision-wafer-detection/.claude/agents/training-runner.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-detection/.claude/agents/training-runner.md) |
| [advanced/project-recipes/wafer/source-agents/inference-runner.md](advanced/project-recipes/wafer/source-agents/inference-runner.md) | copy | [claude-course-code/agent_group_projects/computer-vision-wafer-detection/.claude/agents/inference-runner.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-detection/.claude/agents/inference-runner.md) |
| [advanced/project-recipes/agent-teams/source-context/api-contract.md](advanced/project-recipes/agent-teams/source-context/api-contract.md) | copy | [claude-course-code/agent_teams/ios-app-flutter-dev/arxiv-2-空白課堂版/_Context/api-contract.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_teams/ios-app-flutter-dev/arxiv-2-%E7%A9%BA%E7%99%BD%E8%AA%B2%E5%A0%82%E7%89%88/_Context/api-contract.md) |
| [advanced/project-recipes/agent-teams/source-context/team-roles.md](advanced/project-recipes/agent-teams/source-context/team-roles.md) | copy | [claude-course-code/agent_teams/ios-app-flutter-dev/arxiv-2-空白課堂版/_Context/team-roles.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_teams/ios-app-flutter-dev/arxiv-2-%E7%A9%BA%E7%99%BD%E8%AA%B2%E5%A0%82%E7%89%88/_Context/team-roles.md) |
| [advanced/project-recipes/wafer/README.md](advanced/project-recipes/wafer/README.md) | reading-reference | [claude-course-code/agent_group_projects/computer-vision-wafer-template/README.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-template/README.md) |
| [advanced/project-recipes/wafer/README.md](advanced/project-recipes/wafer/README.md) | reading-reference | [claude-course-code/agent_group_projects/computer-vision-wafer-detection/scripts/prepare_dataset.py](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-detection/scripts/prepare_dataset.py) |
| [advanced/project-recipes/wafer/README.md](advanced/project-recipes/wafer/README.md) | reading-reference | [claude-course-code/agent_group_projects/computer-vision-wafer-agents-detection-demo/CLAUDE.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_group_projects/computer-vision-wafer-agents-detection-demo/CLAUDE.md) |
| [advanced/project-recipes/agent-teams/README.md](advanced/project-recipes/agent-teams/README.md) | reading-reference | [claude-course-code/agent_teams/ios-app-flutter-dev/agent-team-playbook.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/agent_teams/ios-app-flutter-dev/agent-team-playbook.md) |
| [advanced/matt-flow-mods/.claude-plugin/plugin.json](advanced/matt-flow-mods/.claude-plugin/plugin.json) | copy | [matt-flow-mods/.claude-plugin/plugin.json](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/.claude-plugin/plugin.json) |
| [advanced/matt-flow-mods/.claude-plugin/marketplace.json](advanced/matt-flow-mods/.claude-plugin/marketplace.json) | copy | [matt-flow-mods/.claude-plugin/marketplace.json](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/.claude-plugin/marketplace.json) |
| [advanced/matt-flow-mods/hooks/hooks.json](advanced/matt-flow-mods/hooks/hooks.json) | copy | [matt-flow-mods/hooks/hooks.json](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/hooks/hooks.json) |
| [advanced/matt-flow-mods/hooks/register.tsx](advanced/matt-flow-mods/hooks/register.tsx) | copy | [matt-flow-mods/hooks/register.tsx](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/hooks/register.tsx) |
| [advanced/matt-flow-mods/hooks/register.test.tsx](advanced/matt-flow-mods/hooks/register.test.tsx) | copy | [matt-flow-mods/hooks/register.test.tsx](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/hooks/register.test.tsx) |
| [advanced/matt-flow-mods/types/index.d.ts](advanced/matt-flow-mods/types/index.d.ts) | copy | [matt-flow-mods/types/index.d.ts](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/types/index.d.ts) |
| [advanced/matt-flow-mods/scripts/typecheck](advanced/matt-flow-mods/scripts/typecheck) | copy | [matt-flow-mods/scripts/typecheck](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/scripts/typecheck) |
| [advanced/matt-flow-mods/scripts/live-check](advanced/matt-flow-mods/scripts/live-check) | copy | [matt-flow-mods/scripts/live-check](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/scripts/live-check) |
| [advanced/matt-flow-mods/.githooks/pre-commit](advanced/matt-flow-mods/.githooks/pre-commit) | copy | [matt-flow-mods/.githooks/pre-commit](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/.githooks/pre-commit) |
| [advanced/matt-flow-mods/LICENSE](advanced/matt-flow-mods/LICENSE) | copy | [matt-flow-mods/LICENSE](https://github.com/kevin801221/matt-flow-mods/blob/70b50bc1b822eb18d770f8f75588b3b01f77cc27/LICENSE) |
| [examples/lecture-mini-projects/weekly-haiku/source/commands/weekly-haiku.md](examples/lecture-mini-projects/weekly-haiku/source/commands/weekly-haiku.md) | copy | [claude-course-code/Projects/01-weekly-haiku/.claude/commands/weekly-haiku.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/01-weekly-haiku/.claude/commands/weekly-haiku.md) |
| [examples/lecture-mini-projects/recipe-genie/source/agents/recipe-genie.md](examples/lecture-mini-projects/recipe-genie/source/agents/recipe-genie.md) | copy | [claude-course-code/Projects/02-recipe-genie/.claude/agents/recipe-genie.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/02-recipe-genie/.claude/agents/recipe-genie.md) |
| [examples/lecture-mini-projects/pomodoro/source/hooks/pomodoro.sh](examples/lecture-mini-projects/pomodoro/source/hooks/pomodoro.sh) | copy | [claude-course-code/Projects/04-pomodoro/.claude/hooks/pomodoro.sh](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/04-pomodoro/.claude/hooks/pomodoro.sh) |
| [examples/lecture-mini-projects/pomodoro/source/settings.json](examples/lecture-mini-projects/pomodoro/source/settings.json) | copy | [claude-course-code/Projects/04-pomodoro/try/.claude/settings.json](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/04-pomodoro/try/.claude/settings.json) |
| [examples/lecture-mini-projects/weekly-haiku/modern-skill/SKILL.md](examples/lecture-mini-projects/weekly-haiku/modern-skill/SKILL.md) | adapted | [claude-course-code/Projects/01-weekly-haiku/.claude/commands/weekly-haiku.md](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/01-weekly-haiku/.claude/commands/weekly-haiku.md) |
| [examples/lecture-mini-projects/pomodoro/settings.project.example.json](examples/lecture-mini-projects/pomodoro/settings.project.example.json) | adapted | [claude-course-code/Projects/04-pomodoro/try/.claude/settings.json](https://github.com/kevin801221/claude-course-code/blob/475fe057ed234f836ff3eb06f4c5eecad9e36332/Projects/04-pomodoro/try/.claude/settings.json) |

## 主要調整

- 天氣工作流移除缺失音效 hooks 與固定模型/記憶設定，修正 agent tools 與預載 Skill 的分工；API 失敗即停止，不使用示意值。
- 代理、commands 與 PRP 聚焦輸入、輸出與驗收，不帶大型原專案環境。
- doc-generator 保留可執行 AST 原碼，把說明縮到真實可做的函式草稿範圍。
- 講義的 AgenticRAG notebooks 在指定五庫未找到；改附清楚標示的原創離線控制流程。
- Mods 原碼逐字保留，額外加上中文導讀、版本界線與測試方式。
- 舊講義的 `default` 啟動參數改為本機 2.1.319 支援的 `manual`。

來源 Repo 未修改；未複製模型、資料集、環境檔、個人設定、原 Git 歷史與大型圖片。完整原版請沿固定 commit 連結閱讀。[第三方授權](THIRD_PARTY_NOTICES.md) 隨包保留。
